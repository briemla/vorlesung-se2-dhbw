package lecture;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.time.DayOfWeek;
import java.util.EnumSet;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.loadui.testfx.GuiTest;

import com.sun.javafx.binding.SelectBinding.AsString;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.CheckBox;

public class ActiveDayEditorTest extends GuiTest {

	private ActiveDayEditor activeDayEditor;

	@Override
	protected Parent getRootNode() {
		activeDayEditor = new ActiveDayEditor();
		return activeDayEditor;
	}
	
	@Before
	public void initialize() {
		// TODO initialize some fields for check boxes
	}
	
	@After
	public void cleanUp() {
	}
	
	@Test
	public void clickMonday() throws Exception {
		// TODO test one day, including daysProperty of ActiveDayEditor
		CheckBox monday = find("#monday");
		CheckBox tuesday = find("#tuesday");
		CheckBox workdays = find("#workdays");
		
		assertThat(monday.isSelected(), is(true));
		
		click(monday);
		
		assertThat(monday.isSelected(), is(false));
		assertThat(tuesday.isSelected(), is(true));
		
		assertThat(workdays.isSelected(), is(false));
		
		
		ActiveDays expectedResult = new ActiveDays(EnumSet.complementOf(EnumSet.of(DayOfWeek.MONDAY)));
		ActiveDays current = activeDayEditor.daysProperty().get();
		
		assertThat(current, is(equalTo(expectedResult)));
		
		click("#workdays");
		
		assertThat(monday.isSelected(), is(true));
	}

	@Test
	public void allDays() throws Exception {
		Node workdays = find("#workdays");
		Node weekend = find("#weekend");
		
		click(workdays);
		click(weekend);
	}
}
