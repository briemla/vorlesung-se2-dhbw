package lecture.bigdata.data;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.Path;

public abstract class Data {

    public static URI apl() throws URISyntaxException {
        return Data.class.getResource("apl-2.0.txt").toURI();
    }

    public static URI epl() throws URISyntaxException {
        return Data.class.getResource("epl-1.0.txt").toURI();
    }

    public static URI gpl() throws URISyntaxException {
        return Data.class.getResource("gpl-3.0.txt").toURI();
    }

    public static String wordCountOutput() {
        return "word-count-output";
    }

    public static URI weatherKarlsruhe() throws URISyntaxException {
        return Data.class.getResource("Karlsruhe_Tageswerte_18760101_20081031_02522.txt").toURI();
    }

    public static URI weatherFeldberg() throws URISyntaxException {
        return Data.class.getResource("Feldberg_Tageswerte_19450101_20141231_01346.txt").toURI();
    }

    public static Path temperatureOutput() {
        return new Path("temperature-output");
    }

    public static String temperatureStreamOutput() {
        return "temperature-stream-output";
    }

    public static String wordCountStreamOutput() {
        return "word-count-stream-output";
    }

    public static String wordCountBatchOutput() {
        return "word-count-batch-output";
    }

    public static Path invertedIndexOutput() {
        return new Path("inverted-index");
    }

    public static URI posts() throws URISyntaxException {
        return Data.class.getResource("Posts.xml").toURI();
    }

    public static URI users() throws URISyntaxException {
        return Data.class.getResource("Users.xml").toURI();
    }

    public static URI comments() throws URISyntaxException {
        return Data.class.getResource("Comments.xml").toURI();
    }

    public static Path topTen() {
        return new Path("top-ten");
    }

    public static Path distinct() {
        return new Path("distinct");
    }

    public static Path reduceSideJoinStackoverflow() {
        return new Path("reduce-side-join-stackoverflow");
    }

    public static Path reduceSideJoin() {
        return new Path("reduce-side-join");
    }

    public static URI joinUser() throws URISyntaxException {
        return Data.class.getResource("join-types-user.txt").toURI();
    }

    public static URI joinLocation() throws URISyntaxException {
        return Data.class.getResource("join-types-location.txt").toURI();
    }

    public static Path partitioning() {
        return new Path("partitioning");
    }

    public static Path jobMerging() {
        return new Path("job-merging");
    }

}
