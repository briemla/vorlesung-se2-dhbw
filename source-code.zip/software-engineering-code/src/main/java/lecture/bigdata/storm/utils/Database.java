package lecture.bigdata.storm.utils;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;

import lecture.bigdata.data.Data;
import lecture.bigdata.storm.batch.Count;

public class Database {

    private static final File output = new File(Data.wordCountBatchOutput(), "database.txt");

    private final Map<String, Count> entries = new HashMap<>();

    public Database() {
        super();
        createParentFolder();
    }

    private void createParentFolder() {
        File parent = output.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }
    }

    public Integer update(BigInteger transactionId, String word, Integer count) {
        Count current = entries.get(word);
        if (current == null) {
            Count next = new Count(transactionId, word, count);
            entries.put(word, next);
            printDatabase("new entry:       ");
            return next.getCount();
        } else if (!current.isSame(transactionId)) {
            Count next = current.increment(count, transactionId);
            entries.put(word, next);
            printDatabase("altered entry:   ");
            return next.getCount();
        }
        printDatabase("nothing changed: ");
        return count;
    }

    private void printDatabase(String message) {
        System.out.println(message + entries);
        try {
            Files.write(output.toPath(), printableDatabase().getBytes(), StandardOpenOption.APPEND,
                    StandardOpenOption.CREATE);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private String printableDatabase() {
        return entries.toString() + System.lineSeparator();
    }
}
