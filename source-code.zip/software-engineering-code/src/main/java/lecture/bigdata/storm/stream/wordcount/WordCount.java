package lecture.bigdata.storm.stream.wordcount;

import java.util.Map;
import java.util.TreeMap;

import backtype.storm.topology.BasicOutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBasicBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class WordCount extends BaseBasicBolt {
    private final Map<String, Integer> counts = new TreeMap<>();

    @Override
    public void execute(Tuple tuple, BasicOutputCollector collector) {
        String word = tuple.getString(0);
        Integer count = tuple.getInteger(1);
        incrementCountFor(word, count);
        collector.emit(new Values(counts.toString()));
    }

    private void incrementCountFor(String word, Integer wordCount) {
        Integer count = counts.get(word);
        if (count == null) {
            count = 0;
        }
        count += wordCount;
        counts.put(word, count);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("counts"));
    }
}