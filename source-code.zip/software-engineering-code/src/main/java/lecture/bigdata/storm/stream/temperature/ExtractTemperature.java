package lecture.bigdata.storm.stream.temperature;

import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class ExtractTemperature extends BaseRichBolt {

    private static final String fieldName = "temperature";
    private static final int fieldIndex = 3;

    private OutputCollector collector;

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
    }

    @Override
    public void execute(Tuple input) {
        String[] data = input.getString(0).split(";");
        String potentialNumber = data[fieldIndex];
        if (potentialNumber != null) {
            try {
                double temperature = Double.parseDouble(potentialNumber.trim());
                collector.emit(new Values(temperature));
            } catch (NumberFormatException exception) {
                // not bad
            }
            collector.ack(input);
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields(fieldName));

    }

}
