package lecture.bigdata.storm.stream;

import static java.nio.file.StandardOpenOption.CREATE;
import static java.nio.file.StandardOpenOption.WRITE;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.IRichBolt;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Tuple;

@SuppressWarnings("serial")
public class Save extends BaseRichBolt {

    private final File output;
    private OutputCollector collector;

    public Save(File output) {
        this.output = output;
    }

    public static IRichBolt to(File output) {
        return new Save(output);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        createOutputFile();
    }

    private void createOutputFile() {
        try {
            createFolder();
            output.createNewFile();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private void createFolder() {
        File parent = output.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }
    }

    @Override
    public void execute(Tuple input) {
        try {
            Files.write(output.toPath(), bytesOf(input), CREATE, WRITE);
            collector.ack(input);
        } catch (IOException exception) {
            exception.printStackTrace();
            collector.fail(input);
        }
    }

    private byte[] bytesOf(Tuple input) {
        String values = String.valueOf(input.getValues());
        String line = values + System.lineSeparator();
        return line.getBytes();
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
    }

}
