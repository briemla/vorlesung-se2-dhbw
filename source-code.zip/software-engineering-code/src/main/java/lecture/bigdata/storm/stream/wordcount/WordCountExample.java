package lecture.bigdata.storm.stream.wordcount;

import java.io.File;
import java.net.URISyntaxException;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;
import lecture.bigdata.data.Data;
import lecture.bigdata.storm.stream.LineByLineSpout;
import lecture.bigdata.storm.stream.Save;
import lecture.bigdata.storm.utils.StopStorm;

public class WordCountExample {

    public static void main(String[] args) throws URISyntaxException {
        TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout("sentence1", new LineByLineSpout(Data.apl()));
        builder.setSpout("sentence2", new LineByLineSpout(Data.epl()));
        builder.setBolt("split", new SplitSentence()).shuffleGrouping("sentence1").shuffleGrouping("sentence2");
        builder.setBolt("count", new WordCount()).fieldsGrouping("split", new Fields("word"));
        builder.setBolt("save", Save.to(new File(Data.wordCountStreamOutput(), "count")))
                .shuffleGrouping("count");

        Config config = new Config();
        config.setDebug(false);

        LocalCluster cluster = new LocalCluster();
        cluster.submitTopology("wordCount", config, builder.createTopology());
        StopStorm.showUi();
    }
}
