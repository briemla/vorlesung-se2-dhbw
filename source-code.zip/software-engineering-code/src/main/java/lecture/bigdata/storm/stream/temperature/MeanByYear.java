package lecture.bigdata.storm.stream.temperature;

import java.util.HashMap;
import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class MeanByYear extends BaseRichBolt {

    private static class Mean {
        private double mean = 0.0;
        private int count = 0;

        private double add(double value) {
            mean = (mean * count + value) / (count + 1);
            count++;
            return mean;
        }
    }

    private OutputCollector collector;
    private final String field;
    private Map<Integer, Mean> means;

    public MeanByYear(String field) {
        this.field = field;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        means = new HashMap<>();
    }

    @Override
    public void execute(Tuple input) {
        int year = input.getIntegerByField("year");
        if (!means.containsKey(year)) {
            means.put(year, new Mean());
        }
        Mean mean = means.get(year);
        double temperature = input.getDoubleByField(field);
        double newMean = mean.add(temperature);
        collector.emit(new Values(year, newMean));
        collector.ack(input);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("year", field));
    }

}
