package lecture.bigdata.storm.stream.tracking;

import java.util.HashMap;
import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class WordCount extends BaseRichBolt {

    private OutputCollector collector;
    private Map<String, Integer> count;
    private int overAllCount;

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        count = new HashMap<>();
        overAllCount = 0;
    }

    @Override
    public void execute(Tuple input) {
        overAllCount++;
        if (overAllCount % 5 == 0) {
            collector.fail(input);
            return;
        }
        String word = input.getString(0);
        Integer count = input.getInteger(1);
        increment(word, count);
        collector.emit(new Values(this.count.toString()));
        collector.ack(input);
    }

    private void increment(String word, Integer increment) {
        if (!count.containsKey(word)) {
            count.put(word, 0);
        }
        Integer newCount = count.get(word) + increment;
        count.put(word, newCount);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("counts"));
    }

}
