package lecture.bigdata.storm.batch;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import backtype.storm.coordination.BatchOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.FailedException;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseTransactionalBolt;
import backtype.storm.transactional.ICommitter;
import backtype.storm.transactional.TransactionAttempt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;
import lecture.bigdata.storm.utils.Database;

@SuppressWarnings("serial")
public class SaveBatch extends BaseTransactionalBolt implements ICommitter {

    private static final int failEntry = 3;

    private static final Database database = new Database();

    private Map<String, Integer> store;
    private BatchOutputCollector collector;
    private TransactionAttempt attempt;

    private static int overallCount = 0;

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map conf, TopologyContext context, BatchOutputCollector collector,
            TransactionAttempt attempt) {
        this.collector = collector;
        this.attempt = attempt;
        store = new HashMap<>();
    }

    @Override
    public void execute(Tuple tuple) {
        String word = tuple.getString(1);
        int count = tuple.getInteger(2);
        increment(word, count);
    }

    private void increment(String word, int count) {
        if (!store.containsKey(word)) {
            store.put(word, 0);
        }
        Integer newCount = store.get(word) + count;
        store.put(word, newCount);
    }

    @Override
    public void finishBatch() {
        startBatchUpdate();
        for (Entry<String, Integer> entry : store.entrySet()) {
            String word = entry.getKey();
            Integer count = entry.getValue();
            Integer newCount = database.update(attempt.getTransactionId(), word, count);
            collector.emit(new Values(attempt, word, newCount));
        }
        finishBatchUpdate();
    }

    private void failSometimes() {
        overallCount++;
        if (overallCount == failEntry) {
            throw new FailedException("Fun Fail");
        }
    }

    private void startBatchUpdate() {
        if (!store.isEmpty()) {
            System.out.println("Start update of database for batch: " + attempt.getTransactionId());
        }
    }

    private void finishBatchUpdate() {
        if (!store.isEmpty()) {
            System.out
                    .println("Finish update of database for batch: " + attempt.getTransactionId());
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("id", "word", "count"));
    }

}
