package lecture.bigdata.storm.stream;

public abstract class DateUtils {

    private static final int YEAR_NOT_FOUND = Integer.MIN_VALUE;

    public static Integer yearOf(String date) {
        try {
            return Integer.parseInt(date.substring(0, 4));
        } catch (NumberFormatException exception) {
            return YEAR_NOT_FOUND;
        }
    }

}
