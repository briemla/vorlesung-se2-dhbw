package lecture.bigdata.storm.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import backtype.storm.coordination.BatchOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBatchBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class SplitSentence extends BaseBatchBolt<Object> {

    private BatchOutputCollector collector;
    private Object id;
    private List<String> words;

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map conf, TopologyContext context, BatchOutputCollector collector,
            Object id) {
        this.collector = collector;
        this.id = id;
        words = new ArrayList<>();
    }

    @Override
    public void execute(Tuple tuple) {
        StringTokenizer sentence = new StringTokenizer(tuple.getString(1));
        while (sentence.hasMoreTokens()) {
            words.add(sentence.nextToken().toLowerCase());
        }
    }

    @Override
    public void finishBatch() {
        for (String word : words) {
            collector.emit(new Values(id, word, 1));
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("id", "key", "count"));
    }

}
