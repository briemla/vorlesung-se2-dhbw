package lecture.bigdata.storm.stream.temperature;

import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;
import lecture.bigdata.storm.stream.DateUtils;

@SuppressWarnings("serial")
public class FilterByYear extends BaseRichBolt {

    private final Integer year;
    private OutputCollector collector;

    public FilterByYear(int year) {
        this.year = year;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
    }

    @Override
    public void execute(Tuple input) {
        String data = input.getStringByField("line");
        String[] split = data.split(";");
        if (split.length < 2) {
            return;
        }
        String date = split[1];
        if (year.equals(DateUtils.yearOf(date))) {
            collector.emit(new Values(data));
        }
        collector.ack(input);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("line"));
    }

}
