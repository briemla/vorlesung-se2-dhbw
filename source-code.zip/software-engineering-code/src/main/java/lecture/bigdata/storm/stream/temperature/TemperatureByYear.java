package lecture.bigdata.storm.stream.temperature;

import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;
import lecture.bigdata.storm.stream.DateUtils;

@SuppressWarnings("serial")
public class TemperatureByYear extends BaseRichBolt {

    private OutputCollector collector;

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
    }

    @Override
    public void execute(Tuple input) {
        String line = input.getStringByField("line");
        String[] data = line.split(";");
        if (data.length < 4) {
            return;
        }
        Integer year = DateUtils.yearOf(data[1]);
        String potentialTemperature = data[3];
        try {
            double temperature = Double.parseDouble(potentialTemperature.trim());
            collector.emit(new Values(year, temperature));
        } catch (NumberFormatException exception) {
            // not bad
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("year", "temperature"));
    }

}
