package lecture.bigdata.storm.stream.tracking;

import java.io.File;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;
import lecture.bigdata.data.Data;
import lecture.bigdata.storm.stream.Save;
import lecture.bigdata.storm.utils.StopStorm;

public class TrackingWordCount {

    public static void main(String[] args) {
        String output = Data.wordCountStreamOutput();

        TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout("sentence", new SentenceSpout());
        builder.setBolt("word", new SplitSentence()).shuffleGrouping("sentence");
        builder.setBolt("count", new WordCount()).fieldsGrouping("word", new Fields("word"));
        builder.setBolt("save", Save.to(new File(output, "count"))).shuffleGrouping("count");

        Config config = new Config();
        config.setDebug(true);
        LocalCluster cluster = new LocalCluster();
        cluster.submitTopology("tracking", config, builder.createTopology());
        StopStorm.showUi();
    }
}
