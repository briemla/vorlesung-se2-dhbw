package lecture.bigdata.storm.stream.tracking;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class SentenceSpout extends BaseRichSpout {

    private SpoutOutputCollector collector;
    private List<Values> elements;
    private int currentIndex = 0;

    @SuppressWarnings("rawtypes")
    @Override
    public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
        this.collector = collector;
        elements = Arrays.asList(new Values("Ich gehe nach Hause"), new Values("Er geht Spielen"));
    }

    @Override
    public void nextTuple() {
        if (currentIndex == elements.size()) {
            return;
        }
        collector.emit(elements.get(currentIndex), currentIndex);
        currentIndex++;
    }

    @Override
    public void fail(Object messageId) {
        System.out.println("Failed: " + messageId);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("sentence"));
    }
}
