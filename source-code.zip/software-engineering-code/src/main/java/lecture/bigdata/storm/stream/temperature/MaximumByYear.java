package lecture.bigdata.storm.stream.temperature;

import java.util.HashMap;
import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class MaximumByYear extends BaseRichBolt {

    private OutputCollector collector;
    private final String field;
    private Map<Integer, Double> maxByYear;

    public MaximumByYear(String field) {
        this.field = field;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        maxByYear = new HashMap<>();
    }

    @Override
    public void execute(Tuple input) {
        Integer year = input.getIntegerByField("year");
        if (!maxByYear.containsKey(year)) {
            maxByYear.put(year, 0.0d);
        }
        double currentMax = maxByYear.get(year);
        double value = input.getDoubleByField(field);
        double newMax = Math.max(currentMax, value);
        maxByYear.put(year, newMax);
        collector.emit(new Values(year, newMax));
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("year", field));
    }

}
