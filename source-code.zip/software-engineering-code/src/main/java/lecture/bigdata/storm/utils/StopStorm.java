package lecture.bigdata.storm.utils;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class StopStorm extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Button stop = new Button("Stop Storm");
        stop.setMinHeight(30);
        stop.setMinWidth(200);
        stop.setOnAction(this::exit);
        StackPane pane = new StackPane(stop);
        primaryStage.setScene(new Scene(pane));
        primaryStage.show();
    }

    public void exit(ActionEvent event) {
        System.exit(0);
    }

    public static void showUi() {
        StopStorm.launch();
    }

}
