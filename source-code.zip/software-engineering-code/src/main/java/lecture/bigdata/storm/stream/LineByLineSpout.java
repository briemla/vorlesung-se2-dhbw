package lecture.bigdata.storm.stream;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class LineByLineSpout extends BaseRichSpout {

    private SpoutOutputCollector collector;
    private final URI inputPath;
    private List<String> climate;
    private int currentElement;

    public LineByLineSpout(URI inputFile) {
        inputPath = inputFile;
    }

    @SuppressWarnings({ "rawtypes" })
    @Override
    public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
        this.collector = collector;
        try {
            currentElement = 0;
            climate = Files.lines(Paths.get(inputPath)).collect(Collectors.toList());
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public void nextTuple() {
        if (currentElement >= climate.size()) {
            return;
        }
        collector.emit(new Values(climate.get(currentElement)));
        currentElement++;
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("line"));
    }

}
