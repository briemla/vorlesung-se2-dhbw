package lecture.bigdata.storm.batch;

import java.math.BigInteger;

public class Count {

    private final Object id;
    private final String word;
    private final int count;

    public Count(Object id, String word, int count) {
        super();
        this.id = id;
        this.word = word;
        this.count = count;
    }

    public boolean isSame(BigInteger transactionId) {
        return id.equals(transactionId);
    }

    public Count increment(Integer count, BigInteger transactionId) {
        return new Count(transactionId, word, this.count + count);
    }

    public Integer getCount() {
        return count;
    }

    @Override
    public String toString() {
        return "[id=" + id + ", count=" + count + "]";
    }

}
