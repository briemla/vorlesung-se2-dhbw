package lecture.bigdata.storm.stream.temperature;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;
import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;
import lecture.bigdata.storm.stream.LineByLineSpout;
import lecture.bigdata.storm.stream.SaveByYear;
import lecture.bigdata.storm.utils.StopStorm;

public class TemperatureAnalysis {

    public static void main(String[] args) throws URISyntaxException, IOException {
        FileDeleter.clear(Data.temperatureStreamOutput());
        URI inputFile = Data.weatherKarlsruhe();
        String outputFolder = Data.temperatureStreamOutput();

        TopologyBuilder builder = new TopologyBuilder();

        builder.setSpout("data", new LineByLineSpout(inputFile));
        builder.setBolt("temperature-by-year", new TemperatureByYear()).shuffleGrouping("data");
        builder.setBolt("mean-by-year", new MeanByYear("temperature"))
                .fieldsGrouping("temperature-by-year", new Fields("year"));
        builder.setBolt("save-mean-by-year", SaveByYear.to(new File(outputFolder, "mean")))
                .fieldsGrouping("mean-by-year", new Fields("year"));

        builder.setBolt("max-by-year", new MaximumByYear("temperature"))
                .fieldsGrouping("temperature-by-year", new Fields("year"));
        builder.setBolt("save-max-by-year", SaveByYear.to(new File(outputFolder, "max")))
                .fieldsGrouping("max-by-year", new Fields("year"));

        Config config = new Config();
        config.setDebug(false);

        LocalCluster cluster = new LocalCluster();
        cluster.submitTopology("temperature-analysis", config, builder.createTopology());
        StopStorm.showUi();
    }

}
