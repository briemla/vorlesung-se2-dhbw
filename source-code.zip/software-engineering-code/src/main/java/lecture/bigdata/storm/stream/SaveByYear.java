package lecture.bigdata.storm.stream;

import static java.nio.file.StandardOpenOption.CREATE;
import static java.nio.file.StandardOpenOption.WRITE;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.IRichBolt;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Tuple;

@SuppressWarnings("serial")
public class SaveByYear extends BaseRichBolt {

    private final File outputFolder;
    private OutputCollector collector;

    public SaveByYear(File outputFolder) {
        this.outputFolder = outputFolder;
    }

    public static IRichBolt to(File outputFolder) {
        return new SaveByYear(outputFolder);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        if (!outputFolder.exists()) {
            outputFolder.mkdirs();
        }
    }

    @Override
    public void execute(Tuple input) {
        try {
            File output = new File(outputFolder, input.getIntegerByField("year").toString());
            Files.write(output.toPath(), bytesOf(input), CREATE, WRITE);
            collector.ack(input);
        } catch (IOException exception) {
            exception.printStackTrace();
            collector.fail(input);
        }
    }

    private byte[] bytesOf(Tuple input) {
        String roundedOutput = round(input);
        String line = roundedOutput + System.lineSeparator();
        return line.getBytes();
    }

    private String round(Tuple input) {
        long roundedOutput = Math.round(input.getDoubleByField("temperature") * 100.);
        return String.valueOf(roundedOutput / 100.0);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
    }

}
