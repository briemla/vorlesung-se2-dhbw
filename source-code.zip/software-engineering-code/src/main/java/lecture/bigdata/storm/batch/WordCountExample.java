package lecture.bigdata.storm.batch;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.testing.MemoryTransactionalSpout;
import backtype.storm.transactional.TransactionalTopologyBuilder;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;
import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;
import lecture.bigdata.storm.utils.StopStorm;

@SuppressWarnings("deprecation")
public class WordCountExample {

    private static final int partitionsPerBatch = 1;

    public static void main(String[] args) throws IOException {
        FileDeleter.clear(Data.wordCountBatchOutput());

        MemoryTransactionalSpout spout = new MemoryTransactionalSpout(partitions(),
                new Fields("sentence"), partitionsPerBatch);
        TransactionalTopologyBuilder builder = new TransactionalTopologyBuilder("sentence",
                "sentence", spout);
        builder.setBolt("split", new SplitSentence()).shuffleGrouping("sentence");
        builder.setBolt("count", new WordCount()).shuffleGrouping("split");
        builder.setBolt("save", new SaveBatch()).globalGrouping("count");

        Config config = new Config();
        config.setDebug(false);

        LocalCluster cluster = new LocalCluster();
        cluster.submitTopology("batch-word-count", config, builder.buildTopology());
        StopStorm.showUi();
    }

    private static Map<Integer, List<List<Object>>> partitions() {
        HashMap<Integer, List<List<Object>>> partitions = new HashMap<>();
        partitions.put(0, Arrays.asList(new Values("Ich gehe nach Hause"),
                new Values("Er geht nach Hause"), new Values("Sie geht arbeiten")));
        partitions.put(1, Arrays.asList(new Values("Wir spielen zusammen"),
                new Values("Ein Kind spielt draußen"), new Values("Heute spielen wir")));
        return partitions;
    }
}
