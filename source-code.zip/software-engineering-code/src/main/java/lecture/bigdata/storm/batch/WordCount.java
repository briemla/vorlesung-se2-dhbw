package lecture.bigdata.storm.batch;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import backtype.storm.coordination.BatchOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBatchBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

@SuppressWarnings("serial")
public class WordCount extends BaseBatchBolt<Object> {

    private BatchOutputCollector collector;
    private Object id;
    private Map<String, Integer> database;

    @SuppressWarnings("rawtypes")
    @Override
    public void prepare(Map conf, TopologyContext context, BatchOutputCollector collector,
            Object id) {
        this.collector = collector;
        this.id = id;
        database = new HashMap<>();
    }

    @Override
    public void execute(Tuple tuple) {
        String word = tuple.getString(1);
        int count = tuple.getInteger(2);
        increment(word, count);
    }

    private void increment(String word, Integer count) {
        if (!database.containsKey(word)) {
            database.put(word, 0);
        }
        int newCount = database.get(word) + count;
        database.put(word, newCount);
    }

    @Override
    public void finishBatch() {
        for (Entry<String, Integer> entry : database.entrySet()) {
            collector.emit(new Values(id, entry.getKey(), entry.getValue()));
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("id", "word", "count"));
    }

}
