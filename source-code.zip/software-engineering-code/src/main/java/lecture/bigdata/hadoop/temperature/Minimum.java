package lecture.bigdata.hadoop.temperature;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class Minimum extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {

    @Override
    protected void reduce(IntWritable key, Iterable<DoubleWritable> values,
            Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable>.Context context)
                    throws IOException, InterruptedException {
    }

}
