package lecture.bigdata.hadoop.patterns.invertedindex;

import java.io.IOException;
import java.util.Map;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import lecture.bigdata.hadoop.patterns.utils.Utils;

public class SearchLinks extends Mapper<LongWritable, Text, Text, Text> {

    private static final String questionType = "1";

    @Override
    protected void map(LongWritable key, Text value,
            Mapper<LongWritable, Text, Text, Text>.Context context)
                    throws IOException, InterruptedException {
        Map<String, String> post = Utils.xmlToMap(value.toString());
        if (!post.containsKey("Body")) {
            return;
        }
        if (isQuestion(post)) {
            return;
        }
        String body = post.get("Body");
        String postId = post.get("Id");
        String link = Utils.findWikipediaLinkIn(body);
        if (!link.isEmpty()) {
            context.write(new Text(link), new Text(postId));
        }
    }

    private boolean isQuestion(Map<String, String> post) {
        return questionType.equals(post.get("PostTypeId"));
    }

}
