package lecture.bigdata.hadoop.patterns.invertedindex;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

public class InvertedIndex {

    public static void main(String[] args)
            throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {
        Path output = Data.invertedIndexOutput();
        FileDeleter.clear(output.toString());

        Job job = Job.getInstance();

        job.setMapperClass(SearchLinks.class);
        job.setCombinerClass(AddLinks.class);
        job.setReducerClass(AddLinks.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        job.setNumReduceTasks(1);

        FileInputFormat.addInputPath(job, new Path(Data.posts()));
        FileOutputFormat.setOutputPath(job, output);
        job.waitForCompletion(true);
    }

}
