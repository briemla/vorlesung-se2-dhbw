package lecture.bigdata.hadoop.complete.wordcount;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

/**
 * @author lars
 *
 */
public class WordCountExample {

    private static final int reduceTasks = 1;

    public static void main(String[] args) throws Exception {
        FileDeleter.clear(Data.wordCountOutput());

        Job job = Job.getInstance();

        job.setMapperClass(SplitSentence.class);
        job.setCombinerClass(CountWord.class);
        job.setReducerClass(CountWord.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        job.setNumReduceTasks(reduceTasks);

        FileInputFormat.addInputPath(job, new Path(Data.apl()));
        FileInputFormat.addInputPath(job, new Path(Data.epl()));
        FileInputFormat.addInputPath(job, new Path(Data.gpl()));
        FileOutputFormat.setOutputPath(job, new Path(Data.wordCountOutput()));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

}