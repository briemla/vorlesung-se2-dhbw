package lecture.bigdata.hadoop.patterns.jobmerging;

import java.io.IOException;
import java.util.Map;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import lecture.bigdata.hadoop.patterns.utils.Utils;

public class MergedMapper extends Mapper<Object, Text, Text, IntWritable> {

    private static final String yearPrefix = "Y";
    private static final String userPrefix = "U";
    private static final String ownerUserId = "OwnerUserId";
    private static final IntWritable one = new IntWritable(1);
    private static final String creationDate = "CreationDate";

    @Override
    protected void map(Object key, Text value, Mapper<Object, Text, Text, IntWritable>.Context context)
            throws IOException, InterruptedException {
        Map<String, String> post = Utils.xmlToMap(value.toString());
        mapPostsPerUser(post, context);
        mapPostsPerYear(post, context);
    }

    private void mapPostsPerUser(Map<String, String> post, Mapper<Object, Text, Text, IntWritable>.Context context)
            throws IOException, InterruptedException {
        if (!post.containsKey(ownerUserId)) {
            return;
        }
        String userId = post.get(ownerUserId);
        context.write(new Text(userPrefix + userId), one);
    }

    private void mapPostsPerYear(Map<String, String> post, Mapper<Object, Text, Text, IntWritable>.Context context)
            throws IOException, InterruptedException {
        if (!post.containsKey(creationDate)) {
            return;
        }
        String date = post.get(creationDate);
        String year = date.substring(0, 4);
        context.write(new Text(yearPrefix + year), one);
    }
}
