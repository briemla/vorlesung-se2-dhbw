package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class JoinTable extends Reducer<Text, Text, Text, Text> {

    private List<String> users = new ArrayList<>();
    private List<String> locations = new ArrayList<>();

    @Override
    protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {
        clear();
        parse(values);
        join(context);
    }

    private void clear() {
        users.clear();
        locations.clear();
    }

    private void parse(Iterable<Text> values) {
        for (Text value : values) {
            if (isUser(value)) {
                users.add(removePrefix(value));
            } else {
                locations.add(removePrefix(value));
            }
        }
    }

    private boolean isUser(Text value) {
        return value.toString().startsWith("U");
    }

    private String removePrefix(Text text) {
        String value = text.toString();
        return value.substring(1, value.length());
    }

    private void join(Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        String joinType = context.getConfiguration().get("join.type");
        JoinType executor = JoinType.valueOf(joinType);
        executor.join(users, locations, context);
    }

}
