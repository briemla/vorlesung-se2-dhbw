package lecture.bigdata.hadoop.patterns.partitioning;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import lecture.bigdata.hadoop.patterns.utils.Utils;

public class PerDay extends Mapper<Object, Text, IntWritable, Text> {

    private static final String creationDateElement = "CreationDate";
    private static final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

    @Override
    protected void map(Object key, Text value, Mapper<Object, Text, IntWritable, Text>.Context context)
            throws IOException, InterruptedException {
        Map<String, String> post = Utils.xmlToMap(value.toString());
        if (!post.containsKey(creationDateElement)) {
            return;
        }
        String creationDate = post.get(creationDateElement);
        int dayOfWeek = getDayOfWeekFrom(creationDate);
        context.write(new IntWritable(dayOfWeek), value);
    }

    private static int getDayOfWeekFrom(String date) {
        try {
            Date creationDate = format.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(creationDate);
            return calendar.get(Calendar.DAY_OF_WEEK);

        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

}
