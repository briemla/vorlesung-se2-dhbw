package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;
import java.util.Map;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import lecture.bigdata.hadoop.patterns.utils.Utils;

public class Comment extends Mapper<Object, Text, Text, Text> {

    private static final String postIdElement = "PostId";

    @Override
    protected void map(Object key, Text value, Mapper<Object, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {
        Map<String, String> comment = Utils.xmlToMap(value.toString());
        if (!comment.containsKey(postIdElement)) {
            return;
        }
        String postId = comment.get(postIdElement);
        context.write(new Text(postId), new Text("C" + value.toString()));
    }

}
