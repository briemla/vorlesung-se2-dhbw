package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.xml.sax.SAXException;

import lecture.bigdata.hadoop.patterns.utils.Utils;

public class Join extends Reducer<Text, Text, Text, NullWritable> {

    private static final String commentPrefix = "C";

    @Override
    protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, Text, NullWritable>.Context context)
            throws IOException, InterruptedException {
        List<String> comments = new ArrayList<>();
        String post = null;
        for (Text element : values) {
            if (isComment(element)) {
                comments.add(removePrefix(element));
            } else {
                post = removePrefix(element);
            }
        }
        join(comments, post, context);
    }

    private void join(List<String> comments, String post, Reducer<Text, Text, Text, NullWritable>.Context context)
            throws InterruptedException {
        if (post == null) {
            return;
        }
        try {
            String joinedElements = Utils.nest(post, comments);
            context.write(new Text(joinedElements), NullWritable.get());
        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            throw new RuntimeException(e);
        }
    }

    private String removePrefix(Text element) {
        String value = element.toString();
        String withoutPrefix = value.substring(1, value.length());
        return withoutPrefix.trim();
    }

    private boolean isComment(Text element) {
        return element.toString().startsWith(commentPrefix);
    }

}
