package lecture.bigdata.hadoop.complete.temperature;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

public class TemperatureAnalysis {

    private static final int reducer = 1;

    public static void main(String[] args)
            throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {
        FileDeleter.clear(Data.temperatureOutput().toString());

        Job analysis = Job.getInstance();
        analysis.setMapperClass(ExtractTemperature.class);
        analysis.setReducerClass(Calculate.maximum());
        analysis.setNumReduceTasks(reducer);

        FileInputFormat.addInputPath(analysis, new Path(Data.weatherFeldberg()));
        FileInputFormat.addInputPath(analysis, new Path(Data.weatherKarlsruhe()));
        FileOutputFormat.setOutputPath(analysis, Data.temperatureOutput());
        analysis.setOutputKeyClass(IntWritable.class);
        analysis.setOutputValueClass(DoubleWritable.class);

        System.exit(analysis.waitForCompletion(true) ? 0 : 1);
    }

}
