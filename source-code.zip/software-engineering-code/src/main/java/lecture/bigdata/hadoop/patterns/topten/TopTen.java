package lecture.bigdata.hadoop.patterns.topten;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TopTen extends Reducer<LongWritable, Text, LongWritable, Text> {

    private final TreeMap<Long, List<String>> topUsers = new TreeMap<>();

    @Override
    protected void reduce(LongWritable key, Iterable<Text> values,
            Reducer<LongWritable, Text, LongWritable, Text>.Context context)
                    throws IOException, InterruptedException {
        List<String> users = new ArrayList<>();
        values.forEach(text -> users.add(text.toString()));
        topUsers.put(key.get(), users);
        if (10 < topUsers.size()) {
            topUsers.pollFirstEntry();
        }
    }

    @Override
    protected void cleanup(Reducer<LongWritable, Text, LongWritable, Text>.Context context)
            throws IOException, InterruptedException {
        int writtenUsers = 0;
        for (Entry<Long, List<String>> entry : topUsers.entrySet()) {
            Long reputation = entry.getKey();
            List<String> users = entry.getValue();
            for (String user : users) {
                context.write(new LongWritable(reputation), new Text(user));
                writtenUsers++;
                if (10 <= writtenUsers) {
                    return;
                }
            }
        }

    }

}
