package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class User extends Mapper<Object, Text, Text, Text> {
    
    @Override
    protected void map(Object key, Text value, Mapper<Object, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {
        String[] splitted = value.toString().split(" ");
        String id = splitted[0];
        String name = splitted[1];
        
        context.write(new Text(id), new Text("U" + name));
    }

}
