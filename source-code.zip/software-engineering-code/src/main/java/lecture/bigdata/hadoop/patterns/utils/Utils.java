package lecture.bigdata.hadoop.patterns.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Utils {

    private static final String empty = "";
    private static DocumentBuilder builder;

    static {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This helper function parses the StackOverflow record, storing the
     * attribute names and values into a Map
     *
     * Returns an empty map if a parsing exception occurred
     *
     * @param xml
     *            The XML to parse
     * @return The map containing the attribute names and values, or an empty
     *         map if a parsing exception occurred
     */
    public static Map<String, String> xmlToMap(String xml) {
        Document document;
        try {
            document = builder.parse(new ByteArrayInputStream(xml.getBytes()));
        } catch (SAXException | IOException e) {
            return new HashMap<>();
        }

        Map<String, String> map = new HashMap<>();
        NamedNodeMap attributes = document.getDocumentElement().getAttributes();
        for (int i = 0; i < attributes.getLength(); ++i) {
            Node node = attributes.item(i);
            if (node.getNodeType() == Node.ATTRIBUTE_NODE) {
                map.put(node.getNodeName(), node.getNodeValue());
            }
        }
        return map;
    }

    public static String findWikipediaLinkIn(String text) {
        String html = StringEscapeUtils.unescapeHtml(text);
        int linkStart = html.indexOf("\"http://en.wikipedia.org");
        if (-1 == linkStart) {
            return empty;
        }
        int linkEnd = html.indexOf('"', linkStart + 1);
        if (-1 == linkEnd) {
            return empty;
        }
        int hash = html.indexOf('#', linkStart + 1);
        if (-1 != hash && hash < linkEnd) {
            return html.substring(linkStart + 1, hash);
        }
        return html.substring(linkStart + 1, linkEnd);
    }

    public static String nest(String parent, List<String> children)
            throws ParserConfigurationException, SAXException, IOException, TransformerException {
        Document document = builder.newDocument();

        Element parentElement = convertStringToXml(parent);
        Element newParent = document.createElement(parentElement.getTagName());
        copyAttributes(parentElement, newParent);
        for (String child : children) {
            Element childElement = convertStringToXml(child);
            Element newChild = document.createElement(childElement.getTagName());
            copyAttributes(childElement, newChild);
            newParent.appendChild(newChild);
        }

        document.appendChild(newParent);

        return asString(document);
    }

    private static String asString(Document document) throws TransformerException {
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        StringWriter result = new StringWriter();
        transformer.transform(new DOMSource(document), new StreamResult(result));
        return result.toString().replaceAll("\n|\r", "").trim();
    }

    private static void copyAttributes(Element oldElement, Element newElement) {
        NamedNodeMap attributes = oldElement.getAttributes();
        for (int index = 0; index < attributes.getLength(); index++) {
            Attr oldItem = (Attr) attributes.item(index);
            newElement.setAttribute(oldItem.getName(), oldItem.getValue());
        }
    }

    private static Element convertStringToXml(String parent) throws SAXException, IOException {
        return builder.parse(new InputSource(new StringReader(parent))).getDocumentElement();
    }
}
