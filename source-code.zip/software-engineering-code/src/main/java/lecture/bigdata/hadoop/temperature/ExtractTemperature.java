package lecture.bigdata.hadoop.temperature;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ExtractTemperature extends Mapper<LongWritable, Text, IntWritable, DoubleWritable> {

    @Override
    protected void map(LongWritable key, Text value,
            Mapper<LongWritable, Text, IntWritable, DoubleWritable>.Context context)
                    throws IOException, InterruptedException {
    }

}
