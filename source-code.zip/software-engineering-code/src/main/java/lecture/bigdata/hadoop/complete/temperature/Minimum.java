package lecture.bigdata.hadoop.complete.temperature;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class Minimum extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {

    @Override
    protected void reduce(IntWritable key, Iterable<DoubleWritable> values,
            Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable>.Context context)
                    throws IOException, InterruptedException {
        double minimum = Double.MAX_VALUE;
        for (DoubleWritable value : values) {
            minimum = Math.min(minimum, value.get());
        }
        context.write(key, new DoubleWritable(minimum));
    }

}
