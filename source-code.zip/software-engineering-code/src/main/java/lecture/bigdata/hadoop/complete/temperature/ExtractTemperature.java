package lecture.bigdata.hadoop.complete.temperature;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ExtractTemperature extends Mapper<LongWritable, Text, IntWritable, DoubleWritable> {

    @Override
    protected void map(LongWritable key, Text value,
            Mapper<LongWritable, Text, IntWritable, DoubleWritable>.Context context)
                    throws IOException, InterruptedException {
        String[] values = value.toString().split(";");
        if (values.length < 4) {
            return;
        }
        if (value.toString().contains("STATIONS_ID")) {
            return;
        }
        IntWritable year = toYear(values[1]);
        DoubleWritable temperature = toDouble(values[3]);
        context.write(year, temperature);
    }

    private IntWritable toYear(String value) {
        try {
            return new IntWritable(Integer.parseInt(value.substring(0, 4)));
        } catch (NumberFormatException exception) {
            return new IntWritable(Integer.MIN_VALUE);
        }
    }

    private DoubleWritable toDouble(String value) {
        try {
            return new DoubleWritable(Double.parseDouble(value));
        } catch (NumberFormatException exception) {
            return new DoubleWritable(Double.NaN);
        }
    }
}
