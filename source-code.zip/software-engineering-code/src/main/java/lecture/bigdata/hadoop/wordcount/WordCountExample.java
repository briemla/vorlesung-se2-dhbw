package lecture.bigdata.hadoop.wordcount;

import java.io.IOException;
import java.net.URISyntaxException;

public class WordCountExample {

    public static void main(String[] args)
            throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {

    }

}
