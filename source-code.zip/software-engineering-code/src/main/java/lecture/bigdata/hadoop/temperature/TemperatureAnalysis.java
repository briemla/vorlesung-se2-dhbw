package lecture.bigdata.hadoop.temperature;

import java.io.IOException;
import java.net.URISyntaxException;

public class TemperatureAnalysis {

    public static void main(String[] args)
            throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {
    }

}
