package lecture.bigdata.hadoop.patterns.partitioning;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class DayOfWeekPartitioner extends Partitioner<IntWritable, Text> {

    /**
     * Remove 1 because days of week start with value 1 on Sunday
     */
    @Override
    public int getPartition(IntWritable key, Text value, int numPartitions) {
        return key.get() - 1;
    }
}
