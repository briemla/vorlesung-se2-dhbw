package lecture.bigdata.hadoop.patterns.topten;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable.DecreasingComparator;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

public class TopTenExample {

    public static void main(String[] args)
            throws IOException, URISyntaxException, ClassNotFoundException, InterruptedException {
        FileDeleter.clear(Data.topTen().toString());

        Job job = Job.getInstance();

        job.setMapperClass(Users.class);
        job.setCombinerClass(TopTen.class);
        job.setReducerClass(TopTen.class);
        job.setSortComparatorClass(DecreasingComparator.class);
        job.setNumReduceTasks(1);

        FileInputFormat.setInputPaths(job, new Path(Data.users()));
        FileOutputFormat.setOutputPath(job, Data.topTen());

        job.waitForCompletion(true);
    }

}
