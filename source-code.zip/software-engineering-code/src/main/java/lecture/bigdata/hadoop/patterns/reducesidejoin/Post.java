package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;
import java.util.Map;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import lecture.bigdata.hadoop.patterns.utils.Utils;

public class Post extends Mapper<Object, Text, Text, Text> {

    private static final String idElement = "Id";

    @Override
    protected void map(Object key, Text value, Mapper<Object, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {
        Map<String, String> post = Utils.xmlToMap(value.toString());
        if (!post.containsKey(idElement)) {
            return;
        }
        String id = post.get(idElement);
        context.write(new Text(id), new Text("P" + value.toString()));
    }

}
