package lecture.bigdata.hadoop.patterns.invertedindex;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class AddLinks extends Reducer<Text, Text, Text, Text> {

    @Override
    protected void reduce(Text key, Iterable<Text> values,
            Reducer<Text, Text, Text, Text>.Context context)
                    throws IOException, InterruptedException {

        StringBuilder postLinks = new StringBuilder();
        for (Text text : values) {
            postLinks.append(text.toString() + ",");
        }

        // Links auf Wikipedia Seite einfügen
        context.write(key, new Text(postLinks.toString()));
    }

}
