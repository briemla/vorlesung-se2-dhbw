package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

public class ReduceSideJoinStackOverflow {

    public static void main(String[] args)
            throws IOException, URISyntaxException, ClassNotFoundException, InterruptedException {
        FileDeleter.clear(Data.reduceSideJoinStackoverflow().toString());
        Job reduceSideJoin = Job.getInstance();

        Path comments = new Path(Data.comments());
        Path posts = new Path(Data.posts());
        MultipleInputs.addInputPath(reduceSideJoin, comments, TextInputFormat.class, Comment.class);
        MultipleInputs.addInputPath(reduceSideJoin, posts, TextInputFormat.class, Post.class);

        reduceSideJoin.setReducerClass(Join.class);
        reduceSideJoin.setOutputFormatClass(TextOutputFormat.class);
        FileOutputFormat.setOutputPath(reduceSideJoin, Data.reduceSideJoinStackoverflow());

        reduceSideJoin.setOutputKeyClass(Text.class);
        reduceSideJoin.setNumReduceTasks(1);
        reduceSideJoin.waitForCompletion(true);
    }

}
