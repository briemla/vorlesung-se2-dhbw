package lecture.bigdata.hadoop.patterns.jobmerging;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

public class JobMerging {

    public static void main(String[] args)
            throws IOException, URISyntaxException, ClassNotFoundException, InterruptedException {
        FileDeleter.clear(Data.jobMerging().toString());

        Job merging = Job.getInstance();

        merging.setMapperClass(MergedMapper.class);
        merging.setReducerClass(MergedReducer.class);

        Path posts = new Path(Data.posts());
        FileInputFormat.addInputPath(merging, posts);
        FileOutputFormat.setOutputPath(merging, Data.jobMerging());
        MultipleOutputs.addNamedOutput(merging, MergedReducer.postsPerUser, TextOutputFormat.class,
                Text.class, IntWritable.class);
        MultipleOutputs.addNamedOutput(merging, MergedReducer.postsPerYear, TextOutputFormat.class,
                Text.class, IntWritable.class);

        merging.setOutputKeyClass(Text.class);
        merging.setOutputValueClass(IntWritable.class);

        merging.waitForCompletion(true);
    }

}
