package lecture.bigdata.hadoop.complete.temperature;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class Mean extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {

    @Override
    protected void reduce(IntWritable key, Iterable<DoubleWritable> values,
            Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable>.Context context)
                    throws IOException, InterruptedException {
        double sum = 0.0d;
        int count = 0;
        for (DoubleWritable value : values) {
            sum += value.get();
            count++;
        }
        double mean = sum / (count);
        context.write(key, new DoubleWritable(mean));
    }

}
