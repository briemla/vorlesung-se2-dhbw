package lecture.bigdata.hadoop.complete.wordcount;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SplitSentence extends Mapper<Object, Text, Text, IntWritable> {

    private static final IntWritable number = new IntWritable(1);

    @Override
    protected void map(Object key, Text value, Context context)
            throws IOException, InterruptedException {

        StringTokenizer words = new StringTokenizer(value.toString());
        while (words.hasMoreTokens()) {
            context.write(keyOf(words.nextToken()), number);
        }
    }

    private Text keyOf(String word) {
        return new Text(word);
    }
}