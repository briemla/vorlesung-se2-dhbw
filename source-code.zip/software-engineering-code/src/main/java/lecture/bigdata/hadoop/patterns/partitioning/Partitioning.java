package lecture.bigdata.hadoop.patterns.partitioning;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

public class Partitioning {

    private static final int daysPerWeek = 7;

    public static void main(String[] args)
            throws IOException, URISyntaxException, ClassNotFoundException, InterruptedException {
        FileDeleter.clear(Data.partitioning().toString());

        Job partitioning = Job.getInstance();
        partitioning.setMapperClass(PerDay.class);
        partitioning.setPartitionerClass(DayOfWeekPartitioner.class);
        partitioning.setReducerClass(IdentityReducer.class);

        partitioning.setNumReduceTasks(daysPerWeek);
        partitioning.setOutputKeyClass(IntWritable.class);

        Path posts = new Path(Data.posts());
        FileInputFormat.addInputPath(partitioning, posts);
        FileOutputFormat.setOutputPath(partitioning, Data.partitioning());

        partitioning.waitForCompletion(true);
    }
}
