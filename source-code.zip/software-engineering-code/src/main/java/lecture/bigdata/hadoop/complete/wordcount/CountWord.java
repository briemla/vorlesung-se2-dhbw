package lecture.bigdata.hadoop.complete.wordcount;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CountWord extends Reducer<Text, IntWritable, Text, IntWritable> {

    private final IntWritable count = new IntWritable();

    public CountWord() {
    }

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context)
            throws IOException, InterruptedException {
        int totalCount = 0;
        for (IntWritable count : values) {
            totalCount += count.get();
        }
        count.set(totalCount);
        context.write(key, count);
    }
}