package lecture.bigdata.hadoop.patterns.jobmerging;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

public class MergedReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

    public static final String postsPerUser = "PostsPerUser";
    public static final String postsPerYear = "PostsPerYear";

    private static final String userPrefix = "U";
    private MultipleOutputs<Text, IntWritable> output;

    @Override
    protected void setup(Reducer<Text, IntWritable, Text, IntWritable>.Context context)
            throws IOException, InterruptedException {
        output = new MultipleOutputs<>(context);
    }

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values,
            Reducer<Text, IntWritable, Text, IntWritable>.Context context) throws IOException, InterruptedException {
        String outputFile = isUser(key) ? postsPerUser : postsPerYear;
        String rawKey = removePrefix(key.toString());
        count(rawKey, values, outputFile);
    }

    private String removePrefix(String text) {
        return text.substring(1, text.length());
    }

    private boolean isUser(Text key) {
        return key.toString().startsWith(userPrefix);
    }

    private void count(String key, Iterable<IntWritable> values, String outputFile) throws IOException, InterruptedException {
        int sum = 0;
        for (IntWritable value : values) {
            sum += value.get();
        }
        output.write(outputFile, new Text(key), new IntWritable(sum));
    }

    @Override
    protected void cleanup(Reducer<Text, IntWritable, Text, IntWritable>.Context context)
            throws IOException, InterruptedException {
        output.close();
    }
}
