package lecture.bigdata.hadoop;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

public final class FileDeleter extends SimpleFileVisitor<Path> {

    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
        Files.deleteIfExists(file);
        return super.visitFile(file, attrs);
    }

    @Override
    public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
        Files.deleteIfExists(dir);
        return super.postVisitDirectory(dir, exc);
    }

    public static void clear(String outputFolder) throws IOException {
        File outputDirectory = new File(outputFolder);
        if (!outputDirectory.exists()) {
            return;
        }
        Files.walkFileTree(outputDirectory.toPath(), new FileDeleter());
    }
}