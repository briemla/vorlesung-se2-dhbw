package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import lecture.bigdata.data.Data;
import lecture.bigdata.hadoop.FileDeleter;

public class ReduceSideJoin {

    public static void main(String[] args)
            throws IOException, URISyntaxException, ClassNotFoundException, InterruptedException {
        FileDeleter.clear(Data.reduceSideJoin().toString());

        Configuration configuration = new Configuration();
        configuration.set("join.type", JoinType.ANTI.name());
        Job join = Job.getInstance(configuration);

        Path user = new Path(Data.joinUser());
        Path location = new Path(Data.joinLocation());
        MultipleInputs.addInputPath(join, user, TextInputFormat.class, User.class);
        MultipleInputs.addInputPath(join, location, TextInputFormat.class, Location.class);

        join.setReducerClass(JoinTable.class);
        FileOutputFormat.setOutputPath(join, Data.reduceSideJoin());

        join.setOutputKeyClass(Text.class);
        join.setOutputValueClass(Text.class);

        join.waitForCompletion(true);
    }

}
