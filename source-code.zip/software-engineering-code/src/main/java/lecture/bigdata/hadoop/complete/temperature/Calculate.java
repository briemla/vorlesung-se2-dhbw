package lecture.bigdata.hadoop.complete.temperature;

public class Calculate {

    public static Class<Mean> mean() {
        return Mean.class;
    }

    public static Class<Maximum> maximum() {
        return Maximum.class;
    }

    public static Class<Minimum> minimum() {
        return Minimum.class;
    }

}
