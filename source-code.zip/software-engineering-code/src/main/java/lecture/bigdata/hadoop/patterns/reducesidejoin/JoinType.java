package lecture.bigdata.hadoop.patterns.reducesidejoin;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public enum JoinType {
    INNER {

        @Override
        public void join(List<String> users, List<String> locations,
                Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
            for (String user : users) {
                for (String location : locations) {
                    context.write(new Text(user), new Text(location));
                }
            }
        }
    },
    LEFT_OUTER {

        @Override
        public void join(List<String> users, List<String> locations,
                Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
            for (String user : users) {
                if (locations.isEmpty()) {
                    context.write(new Text(user), emptyText);
                }
                for (String location : locations) {
                    context.write(new Text(user), new Text(location));
                }
            }
        }
    },
    RIGHT_OUTER {

        @Override
        public void join(List<String> users, List<String> locations,
                Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
            if (users.isEmpty()) {
                for (String location : locations) {
                    context.write(emptyText, new Text(location));
                }
            }
            for (String user : users) {
                for (String location : locations) {
                    context.write(new Text(user), new Text(location));
                }
            }
        }
    },
    OUTER {

        @Override
        public void join(List<String> users, List<String> locations,
                Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
            if (users.isEmpty()) {
                for (String location : locations) {
                    context.write(emptyText, new Text(location));
                }
            }
            for (String user : users) {
                if (locations.isEmpty()) {
                    context.write(new Text(user), emptyText);
                }
                for (String location : locations) {
                    context.write(new Text(user), new Text(location));
                }
            }
        }
    },
    ANTI {

        @Override
        public void join(List<String> users, List<String> locations,
                Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
            if (users.isEmpty()) {
                for (String location : locations) {
                    context.write(emptyText, new Text(location));
                }
            }
            if (locations.isEmpty()) {
                for (String user : users) {
                    context.write(new Text(user), emptyText);
                }
            }
        }
    };

    private static final Text emptyText = new Text("null");

    public abstract void join(List<String> user, List<String> location,
            Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException;
}
