package lecture.bigdata.hadoop.patterns.topten;

import java.io.IOException;
import java.util.Map;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import lecture.bigdata.hadoop.patterns.utils.Utils;

public class Users extends Mapper<Object, Text, LongWritable, Text> {

    @Override
    protected void map(Object key, Text value,
            Mapper<Object, Text, LongWritable, Text>.Context context)
                    throws IOException, InterruptedException {
        Map<String, String> user = Utils.xmlToMap(value.toString());
        if (!user.containsKey("Reputation")) {
            return;
        }
        int reputation = Integer.parseInt(user.get("Reputation"));
        String id = user.get("Id");
        context.write(new LongWritable(reputation), new Text(id));
    }
}
