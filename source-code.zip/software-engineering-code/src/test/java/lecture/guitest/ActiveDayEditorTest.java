package lecture.guitest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.loadui.testfx.GuiTest;

import lecture.guitest.ActiveDayEditor;

import javafx.scene.Parent;

public class ActiveDayEditorTest extends GuiTest {

	private ActiveDayEditor activeDayEditor;

	@Override
	protected Parent getRootNode() {
		// TODO return ActiveDayEditor, create field
		return activeDayEditor;
	}
	
	@Before
	public void initialise() {
		// TODO initialise some fields for check boxes
	}
	
	@After
	public void cleanUp() {
	}
	
	@Test
	public void clickMonday() throws Exception {
		// TODO test one day, including daysProperty of ActiveDayEditor
	}

}
